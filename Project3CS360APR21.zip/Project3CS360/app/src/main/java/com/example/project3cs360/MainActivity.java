package com.example.project3cs360;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import android.widget.ToggleButton;

import java.util.List;

public class MainActivity extends AppCompatActivity
{
    private EditText editTextEventName; //texts for event name and time
    private EditText editTextEventTime;

    private Button buttonAddEvent; //add event button
    private ToggleButton toggleNotificationButton; //toggle SMS notifications on / off with this

    private ListView listViewEvents; //display existing events

    private ArrayAdapter<String> adapter; //access info from list

    private EventDatabaseManager eventManager; //manages user events

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        eventManager = new EventDatabaseManager(this);

        //assign all things to elements of the layout
        editTextEventName = findViewById(R.id.editTextEventName);
        editTextEventTime = findViewById(R.id.editTextEventTime);
        buttonAddEvent = findViewById(R.id.buttonAddEvent);
        listViewEvents = findViewById(R.id.listViewEvents);
        toggleNotificationButton = findViewById(R.id.toggleSMSButton);

        updateEventList(); //if there are events that the user saved, fill up the listview with them.

        //when user clicks on add event:
        buttonAddEvent.setOnClickListener(v ->
        {
            String eventName = editTextEventName.getText().toString(); //get input from the two plaintexts
            String eventTime = editTextEventTime.getText().toString();

            if (!eventName.isEmpty() && !eventTime.isEmpty())
            {
                eventManager.addEvent(eventName, eventTime); //add new event to the database manager.

                editTextEventName.setText(""); //reset text to show hint again afterward
                editTextEventTime.setText("");

                updateEventList(); //update the list view

                if (toggleNotificationButton.isChecked())  { Toast.makeText(MainActivity.this, "TODO:  Send notifications", Toast.LENGTH_SHORT).show(); }
                //I couldn't make it so that it requests notification permissions in time to finish this.
            }
            else { Toast.makeText(MainActivity.this, "Missing event name / time", Toast.LENGTH_SHORT).show(); }
        });

        //if the user long presses on an event, delete it.
        listViewEvents.setOnItemLongClickListener((parent, view, position, id) ->
        {
            String eventName = adapter.getItem(position); //find item at position
            if (eventName != null) //in case of pressing on an empty list
            {
                eventManager.deleteEvent(eventName);
                updateEventList(); //reset list view.
                return true;
            }
            return false;
        });
    }

    private void updateEventList() //uses the adapter to put events into the list
    {
        List<String> events = eventManager.getAllEvents();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, events);
        listViewEvents.setAdapter(adapter);
    }
}