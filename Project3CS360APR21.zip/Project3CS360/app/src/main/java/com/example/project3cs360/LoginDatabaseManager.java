package com.example.project3cs360;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

//this class is used to manage logins, by interacting with an sqlite database.
public class LoginDatabaseManager extends SQLiteOpenHelper
{
    //create database
    private static final int DATABASE_VERSION = 1; //initial vers
    private static final String DATABASE_NAME = "user.db"; //db name
    private static final String TABLE_NAME = "users"; //table name
    private static final String COLUMN_ID = "_id"; //table with id, username, and password
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD = "password";

    //this creates the table in the database, with an id number, a username, and a password.
    private static final String SQL_CREATE_ENTRIES = "CREATE TABLE " +
            TABLE_NAME + " (" +
            COLUMN_ID + " INTEGER PRIMARY KEY," +
            COLUMN_USERNAME + " TEXT," +
            COLUMN_PASSWORD + " TEXT)";

    //undo / delete the table if it exists already.  stops duplication when making changes to the db.
    private static final String SQL_DELETE_ENTRIES = "DROP TABLE IF EXISTS " + TABLE_NAME;

    //initialize the database via superclass from sqlite.
    public LoginDatabaseManager(Context context)  { super(context, DATABASE_NAME, null, DATABASE_VERSION); }

    //when the logindatabasemanager is created, runs the code in for SQL_CREATE_ENTRIES.
    @Override
    public void onCreate(SQLiteDatabase db) { db.execSQL(SQL_CREATE_ENTRIES); }

    //runs the crap in SQL_DELETE_ENTRIES similar to onCreate.
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
        db.execSQL(SQL_DELETE_ENTRIES);
        onCreate(db);
    }
}