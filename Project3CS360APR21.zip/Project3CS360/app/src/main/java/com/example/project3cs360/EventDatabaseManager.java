package com.example.project3cs360;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

//this class is used to manage all the events that the user creates, through sqlite.
public class EventDatabaseManager extends SQLiteOpenHelper
{
    private static final int DATABASE_VERSION = 1; //initial vers
    private static final String DATABASE_NAME = "EventsManager"; //db name
    private static final String TABLE_EVENTS = "events"; //table name
    private static final String KEY_ID = "id"; //table with id, username, and time
    private static final String KEY_NAME = "name";
    private static final String KEY_TIME = "time"; //could make this an actual java date.
                                                    //but that's a job for another time.

    //constructor
    public EventDatabaseManager(Context context) { super(context, DATABASE_NAME, null, DATABASE_VERSION); }

    //this creates the table in the database, with an id number, a name, and a time of the event.
    @Override
    public void onCreate(SQLiteDatabase db)
    {
        String CREATE_EVENTS_TABLE = "CREATE TABLE "
                + TABLE_EVENTS + "("
                + KEY_ID + " INTEGER PRIMARY KEY,"
                + KEY_NAME + " TEXT,"
                + KEY_TIME + " TEXT" + ")";
        db.execSQL(CREATE_EVENTS_TABLE);
    }

    //time is unimplemented right now but I plan on making notifications pop up at the given time.
    //since I also haven't implemented the notifications, it doesn't matter.

    //stops duplicated tables when updating/upgrading.
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EVENTS);
        onCreate(db);
    }

    //add new event to table via name and time of the event.
    public void addEvent(String eventName, String eventTime)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_NAME, eventName);
        values.put(KEY_TIME, eventTime);
        db.insert(TABLE_EVENTS, null, values);
        db.close();
    }

    //delete event by name.  I originally considered making the user input the name
    //of the thing they wanted to delete with this, but a long press is so
    //much more convenient.
    public void deleteEvent(String eventName)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_EVENTS, KEY_NAME + " = ?", new String[]{eventName});
        db.close();
    }

    //gets a list of all events in the listview.
    //works pretty similarly to the username / password check.
    public List<String> getAllEvents()
    {
        List<String> eventList = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + TABLE_EVENTS;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.moveToFirst())
        {
            do { eventList.add(cursor.getString(1)); }
            while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return eventList;
    }
}