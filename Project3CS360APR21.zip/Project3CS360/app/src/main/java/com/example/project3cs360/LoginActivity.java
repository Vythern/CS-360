package com.example.project3cs360;

import android.content.ContentValues;
import android.os.Bundle;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity
{
    private EditText editTextUsername; //username and password text
    private EditText editTextPassword;

    private Button buttonLogin; //used to listen for clicks, when user is done logging in.
    private Button buttonCreateAccount;

    private LoginDatabaseManager loginManager; //manage login info with login database.

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        //make references to layout items
        editTextUsername = findViewById(R.id.editTextUsername);
        editTextPassword = findViewById(R.id.editTextPassword);

        buttonLogin = findViewById(R.id.buttonLogin); //buttons for logging in, and for creating an account.
        buttonCreateAccount = findViewById(R.id.buttonCreateAccount);

        loginManager = new LoginDatabaseManager(this);

        //compiler keeps telling me I can convert stuff to lambdas
        buttonLogin.setOnClickListener(v ->
        {
            String username = editTextUsername.getText().toString();
            String password = editTextPassword.getText().toString();

            if (!username.isEmpty() && !password.isEmpty())
            {
                if (verifyUserInfo(username, password))
                {
                    //if user exists in database with password / username combo, then move to main activity.
                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                    startActivity(intent);
                    finish();
                    //end login activity.
                }
                else //user needs to create account, or they input their info wrongly.
                { Toast.makeText(LoginActivity.this, "Wrong username / password", Toast.LENGTH_SHORT).show(); }
            }
            else  { Toast.makeText(this, "Enter your login information", Toast.LENGTH_SHORT).show(); }
        });

        buttonCreateAccount.setOnClickListener(v ->
        {
            String username = editTextUsername.getText().toString();
            String password = editTextPassword.getText().toString();

            //check if username is taken
            if (isUsernameTaken(username)) { Toast.makeText(LoginActivity.this, "Username already in use", Toast.LENGTH_SHORT).show(); }
            //we don't want duplicate usernames in the database.
            else
            {
                //create account if not in use already
                if (createAccount(username, password)) { Toast.makeText(LoginActivity.this, "Account created successfully", Toast.LENGTH_SHORT).show(); }

                //if creating the account failed for any reason
                else { Toast.makeText(LoginActivity.this, "Unknown error creating account", Toast.LENGTH_SHORT).show(); }
            }
        });
    }

    public boolean verifyUserInfo(String username, String password)
    {
        //this section isn't actually responsible for much of anything besides a lookup.
        //it does NOT actually have any power over letting the user in or not.
        //https://stackoverflow.com/questions/64755452/search-for-a-specific-string-in-an-sqlite-database-android-sdk
        SQLiteDatabase db = loginManager.getReadableDatabase();
        String queryString = "SELECT 1 FROM users WHERE username = ? AND password = ?";
        Cursor c = db.rawQuery(queryString, new String[]{username, password});
        boolean result = c.getCount() > 0;
        c.close();
        db.close();
        return result;
    }

    public boolean isUsernameTaken(String user)
    {
        //this is effectively the same thing as the verifyUserInfo method, except with one less string involved.
        SQLiteDatabase db = loginManager.getReadableDatabase();
        String queryString = "SELECT 1 FROM users WHERE username = ?";
        Cursor c = db.rawQuery(queryString, new String[]{user});
        boolean result = c.getCount() > 0;
        c.close();
        db.close();
        return result;
    }

    private boolean createAccount(String username, String password)
    {
        //add user account to database
        //input parameters for username and password,
        //sent to database as a new entry
        SQLiteDatabase db = loginManager.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", password);
        long newRowId = db.insert("users", null, values);
        return newRowId != -1;
    }
}